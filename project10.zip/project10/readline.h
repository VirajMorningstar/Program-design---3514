#ifndef READLINE_H
#define READLINE_H
#include <stdio.h>
int read_line(char str[], int n);
#endif